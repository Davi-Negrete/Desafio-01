# Ejercicio-01-Textos

# Luis David Negrete Otero

## Link: https://cosmic-sunshine-4b9ee6.netlify.app/

## W3C_Validator: Document checking completed. No errors or warnings to show.